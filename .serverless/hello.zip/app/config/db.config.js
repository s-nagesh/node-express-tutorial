module.exports = {
  url: "mongodb+srv://snagesh27:nagesh2727@cluster0.c3bidtm.mongodb.net/node-express-totorial"
};
